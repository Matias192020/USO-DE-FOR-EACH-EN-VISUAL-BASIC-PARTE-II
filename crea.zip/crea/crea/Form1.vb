﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' vector de tipo Date     
        Dim vFecha As Date() = {CDate("12/12/2001"), CDate("02/11/2007")}

        For Each fechas As Date In vFecha
            MsgBox(fechas)
        Next

    End Sub
End Class
